import javax.swing.*;

public class Spiel {

    public static void main(String[] args) {
        Welt welt = new Welt ();
        Spieler spieler = new Spieler ("Steve",10, welt);

        SpielDisplay sD = new SpielDisplay();
        System.out.println("---------------------------");
        welt.generieren();
        System.out.println("---------------------------");
        spieler.abbauen();
        System.out.println("---------------------------");
        welt.showMat();
        System.out.println("---------------------------");
        spieler.crafteSpitzhacke(JOptionPane.showInputDialog("Welche Spitzhacke sollte erstellt werden?"));
        spieler.showInv();
        System.out.println("---------------------------");
        spieler.abbauen();
        System.out.println("---------------------------");
        welt.showMat();
    }


}
