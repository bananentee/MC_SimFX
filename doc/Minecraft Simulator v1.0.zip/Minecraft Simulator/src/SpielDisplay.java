import javax.swing.*;
import java.awt.event.ContainerAdapter;
import java.awt.event.ContainerEvent;

public class SpielDisplay{

    public static void main(String[] args) {
        constructFrame();
    }
	private JPanel spielDisplay;
    private JProgressBar progressBar1;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    private JList genItemsL;

    /* constructors */
    public SpielDisplay() {

    }
    /* object methods */
    public static void constructFrame () {
        JFrame sD = new JFrame("Minecraft Simulator");
        sD.setContentPane(new SpielDisplay().spielDisplay);
        sD.setSize(600,400);
        sD.setVisible(true);
        sD.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }


    /* getters and setters */

}
